from django.apps import AppConfig


class SinappConfig(AppConfig):
    name = 'sinapp'
